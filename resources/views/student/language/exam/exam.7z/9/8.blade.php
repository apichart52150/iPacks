<link rel="stylesheet" href="{{ asset('public/css/draggable.css') }}">
<style>
    .drag-container {
        margin-bottom: 25px;
    }


    .answers-container .dropbox {
        display: inline-block;
    }

    .dropbox {
        border: 2px dashed #ccc;
        border-radius: 5px;
        padding: 3px;
        margin: 5px;
        min-width: 150px;
        min-height: 40px;
        vertical-align: middle;
    }

    .dropbox .drag {
        margin: 0;
    }

    .grid-5 {
        grid-template-columns: repeat(6, 1fr);
    }
</style>
@php
$Q = [
"q1" => "Some people think that old, historic buildings are no need for the city and they should be destroyed and replaced with modern ones. However, other people believe that historic buildings must be preserved in order to know and remember our past. For several reasons that I will mention bellow I agree with those people who want to preserve old, historical buildings. First of all, by preserving historical buildings we pass our history to our future",
"q2" => ". I think that out children should know their history, learn from it and respect it. People need to know their",
"q3" => "and customs, which are priceless and irreplaceable. Our history is our knowledge and power. From my opinion we need to preserve and",
"q4" => "historical buildings. By destroying them we show our disrespect to our forefathers and their",
"q5" => ". Second of all, by preserving historical buildings a city can attract many travelers. Welcoming tourists a city can get many",
"q6" => "including money, which can be spent on preserving historical buildings as well as on improving roads and",
"q7" => ". Also, many tourists mean a lot of new business opportunities. Another important",
"q8" => "of this is that businessmen will be willing to build new recreational centers, hotels, movie theatres, shopping centres to make a city more attractive for travelers. In addition to those practical",
"q9" => ", many people will have the opportunity to get a",
"q10" => ". All this is good for the",
"q11" => "of the city. To",
"q12" => "up, I believe that preserving old, historical buildings can bring only",
];
$end = "to a city and all humankind.";
$A = [
"a1" => "aspect",
"a2" => "benefits",
"a3" => "benefits",
"a4" => "benefits",
"a5" => "economy",
"a6" => "facilities",
"a7" => "generations",
"a8" => "job",
"a9" => "restore",
"a10" => "sum",
"a11" => "traditions",
"a12" => "traditions",
];
@endphp
<div class="row">
    <div class="col-md-12">
        <div class="card-box text-dark font-15">
            <div class="row justify-content-center mb-2">
                <div class="col-md-12">
                    <div class="border border-dark px-2 text-center">
                        <h5>The table shows annual budget allocation for defence and education in a number of different countries.</h5>
                        <div class="drag-container">
                            <div class="d-grid grid-5" id="choices">
                                @foreach ($A as $choices)
                                <div class="drag">{{ $choices }}</div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-2">
                <div class="col-md-12">
                    <div class="border border-dark p-2" style="line-height: 35px;">
                        <div class="answers-container">
                            @foreach($Q as $q)
                            {{ $q }}
                            <div class="dropbox"></div>
                            @endforeach
                            {{ $end }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@section('button-control')
<button id="check-answer" class="btn btn-info">Check Answers</button>
<button id="show-answer" class="d-none btn btn-info">Show Answers</button>
@endsection

@section('js')
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui-touch-punch/0.2.3/jquery.ui.touch-punch.min.js"></script>

<script>
    $("#show-answer").prop("disabled", true);

    const answers = [
         $q1 = "<?php echo $A['a7'] ?>",
         $q2 = "<?php echo $A['a11'] ?>",
         $q3 = "<?php echo $A['a9'] ?>",
         $q4 = "<?php echo $A['a11'] ?>",
         $q5 = "<?php echo $A['a2'] ?>",
         $q6 = "<?php echo $A['a6'] ?>",
         $q7 = "<?php echo $A['a1'] ?>",
         $q8 = "<?php echo $A['a2'] ?>",
         $q9 = "<?php echo $A['a8'] ?>",
         $q10 = "<?php echo $A['a5'] ?>",
         $q11 = "<?php echo $A['a10'] ?>",
         $q12 = "<?php echo $A['a2'] ?>",
    ];

    console.log(answers);

    $(".drag").draggable({
        revert: "invalid",
        cursor: "move",
        opacity: 0.7,
        zIndex: 100,
        containment: ".card-box",
        stop: function(event, ui) {
            if ($("#choices").children().length == 0) {
                $("#check-answer").prop("disabled", false);
            }
        },
    });

    $(".dropbox").droppable({
        accept: ".drag",
        tolerance: "touch",
        zIndex: 100,
        over: function(event, ui) {
            $(this).css("border-color", "#777");
        },
        out: function(event, ui) {
            $(this).css("border-color", "#ccc");
        },
        drop: function(event, ui) {
            if ($(this).children().length > 0) {
                var move = $(this).children().detach();
                $(ui.draggable).css({
                    top: 0,
                    left: 0
                }).parent().append(move);
            }
            $(this).css("border-color", "#ccc");
            $(this).append($(ui.draggable).css({
                top: 0,
                left: 0
            }));
        },
    });

        $("#check-answer").on("click", () => {
$('#show-answer').addClass('d-block')
$('#show-answer').removeClass('d-none')
$('#check-answer').addClass('d-none')
        let score = 0

        let droppables = $(".dropbox");

        droppables.each((idx, item) => {
            if ($(item).children().text().trim() == answers[idx]) {
                checkAnswer($(item).children(), 'correct');
                score++
            } else {
                checkAnswer($(item).children(), 'incorrect');
            }
        });

        $(".drag").draggable({
            disabled: true,
        });

        Swal.fire({
            title: "Your score",
            text: score + "",
            timer: 5000,
        }).then(() => {
            $(item).css({
                "font-weight": "bold",
                'color': '#2bc3a5'
            });
        });
        $("#check-answer").prop("disabled", true);
        $("#show-answer").prop("disabled", false);
    });

    $('#show-answer').on('click', () => {
        $('.dropbox').each((idx, item) => {

            if ($(item).children().length == 1) {
                if ($(item).children().hasClass('color-danger')) {
                    if ($(item).children().text(answers[idx])) {
                        $(item).children().removeClass('color-danger')
                    }
                }
            } else {
                $(item).append(`<div class="drag">${ answers[idx] }</div>`)
            }

            $('.drag-container .drag').remove();
        })
    });

    function checkAnswer(ele, status) {
        let bgColor;

        status == 'correct' ? (bgColor = 'color-success') : (bgColor = 'color-danger')

        ele.addClass(bgColor)
    }
$('#show-answer').on('click', function() {
        $('check-answer').addClass('d-none')
        $('.dropbox').each((idx, item) => {

            if($(item).children().length == 1) {
                if($(item).children().hasClass('color-danger')) {
                    if($(item).children().text(answers[idx])) {
                        $(item).children().removeClass('color-danger')
                    }
                }
            } else {
                $(item).append(`<div class="drag">${ answers[idx] }</div>`)
            }

            $('.drag-container .drag').remove();
        })
        $("#show-answer").hide();
    });
</script>
@stop